package com.example.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Base64;

@SpringBootTest
class ExamApplicationTests {

    @Test
    void contextLoads() {

    }

}
