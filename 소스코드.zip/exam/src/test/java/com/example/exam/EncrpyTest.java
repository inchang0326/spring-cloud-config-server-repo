package com.example.exam;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Base64;

public class EncrpyTest {

    public String base64encrypt(String msg) {
        return Base64.getEncoder().encodeToString(msg.getBytes());
    }

    public String base64decrypt(String msg) {
        return new String(Base64.getDecoder().decode(msg));
    }

    @Test
    public void test() {
        String msg = "";
        String encmsg = base64encrypt(msg);
        System.out.println(encmsg);
        System.out.println(base64decrypt(encmsg));

        System.out.println(LocalTime.now());
    }
}
